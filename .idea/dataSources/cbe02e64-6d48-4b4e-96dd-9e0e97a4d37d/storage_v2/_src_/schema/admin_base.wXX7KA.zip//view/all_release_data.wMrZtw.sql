create view all_release_data as select `n`.`news_id`           AS `id`,
                                       `n`.`title`             AS `title`,
                                       `n`.`briefintroduction` AS `briefintroduction`,
                                       `n`.`content`           AS `content`,
                                       `n`.`language`          AS `language`,
                                       '0'                     AS `module_type`,
                                       `n`.`lastmodifytime`    AS `lastmodifytime`
                                from `admin_base`.`biz_news` `n`
                                where (`n`.`status` = 1)
                                union all
                                select `c1`.`course_id`         AS `id`,
                                       `c1`.`title`             AS `title`,
                                       `c1`.`briefintroduction` AS `briefintroduction`,
                                       `c1`.`content`           AS `content`,
                                       `c1`.`language`          AS `language`,
                                       '1'                      AS `module_type`,
                                       `c1`.`lastmodifytime`    AS `lastmodifytime`
                                from `admin_base`.`biz_course` `c1`
                                where (`c1`.`status` = 1)
                                union all
                                select `p`.`professor_id`      AS `id`,
                                       `p`.`title`             AS `title`,
                                       `p`.`briefintroduction` AS `briefintroduction`,
                                       `p`.`content`           AS `content`,
                                       `p`.`language`          AS `language`,
                                       '2'                     AS `module_type`,
                                       `p`.`lastmodifytime`    AS `lastmodifytime`
                                from `admin_base`.`biz_professor` `p`
                                where (`p`.`status` = 1)
                                union all
                                select `c3`.`case_id`           AS `id`,
                                       `c3`.`title`             AS `title`,
                                       `c3`.`briefintroduction` AS `briefintroduction`,
                                       `c3`.`content`           AS `content`,
                                       `c3`.`language`          AS `language`,
                                       '3'                      AS `module_type`,
                                       `c3`.`lastmodifytime`    AS `lastmodifytime`
                                from `admin_base`.`biz_cases` `c3`
                                where (`c3`.`status` = 1);

